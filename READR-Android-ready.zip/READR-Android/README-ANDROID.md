# READR for Android

This ZIP is the READR React/Vite source prepared to be wrapped as an Android app with Capacitor. It is not itself an APK.

## Build an installable APK (Windows)

1. Install **Node.js LTS** and **Android Studio**.
2. Extract this ZIP into a normal folder.
3. Open Command Prompt/Terminal in that folder.
4. Run:

   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

5. Android Studio opens the generated `android` project. Allow it to install/sync the Android Gradle components it requests.
6. To build a test APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. When the build finishes, click **locate** in the notification. The APK is normally under `android/app/build/outputs/apk/debug/`.
8. Transfer that APK to your Android phone and install it. If prompted, allow installation from that file manager.

## After changing the app

Run `npm run android:sync`, then build the APK again in Android Studio.

## Notes

- READR's book data and `public/audio/soft-jazz.mp3` are bundled with the app.
- Android/WebView may block audio autoplay until the first user interaction, depending on device and OS settings. The app already attempts autoplay and has playback controls.
- The app currently references Google Fonts online in `index.html`; without internet, it will use fallback fonts.
- Keep any API keys out of client-side code. Do not put private keys into the APK.
