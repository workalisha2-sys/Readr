import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import rawBooksData from './books.json';

interface BookRaw {
  title: string;
  author: string;
  short: string;
  color: string;
  text: string;
}

interface BooksMap {
  [id: string]: BookRaw;
}

interface Passage {
  start: number;
  words: number;
  ch: string;
  segs: [string, string][]; // ['h' | 'p', text]
}

interface Bookmark {
  pos: number;
  x: string;
}

interface AppState {
  sel: string;
  pos: Record<string, number>;
  marks: Record<string, Bookmark[]>;
  prefs: {
    target: number;
    size: number;
    anim: boolean;
  };
}

const BOOKS = rawBooksData as BooksMap;
const IDS = Object.keys(BOOKS);
const KEY = 'readr:v1';
const OLDKEY = 'tetr:v1';

const countWords = (s: string) => (s.match(/\S+/g) || []).length;
const TOTALS: Record<string, number> = {};
IDS.forEach((id) => {
  TOTALS[id] = countWords(BOOKS[id].text);
});

function tetrSplit(text: string, o?: { target?: number; minTail?: number }): Passage[] {
  const opt = Object.assign({ target: 60, minTail: 0.4 }, o || {});
  const T = opt.target;
  const ABBR = /\b(Mr|Mrs|Ms|Messrs|Dr|St|Mme|Col|Capt|Lt|Gen|Rev|Sr|Jr|vs|No)\.$/;
  const out: Passage[] = [];
  let cur: Passage | null = null;
  let pend: string[] = [];
  let part = '';
  let chap = '';
  let word = 0;

  const open = () => {
    cur = {
      start: word,
      words: 0,
      ch: (part && chap ? part + ' · ' : part) + chap,
      segs: [],
    };
  };

  const flush = () => {
    if (cur && cur.segs.length) out.push(cur);
    cur = null;
  };

  function sentences(p: string): string[] {
    const raw = p.match(/[\s\S]*?[.!?\u2026]+["\u201d\u2019')\]_]*(?=\s|$)\s*|[\s\S]+$/g) || [p];
    const s: string[] = [];
    for (const x of raw) {
      if (s.length && ABBR.test(s[s.length - 1].trim())) {
        s[s.length - 1] += x;
      } else {
        s.push(x);
      }
    }
    return s;
  }

  function chunks(sn: string): string[] {
    const w = sn.match(/\S+\s*/g) || [];
    const r: string[] = [];
    let i = 0;
    while (w.length - i > T * 1.6) {
      let k = i + T;
      let best = -1;
      for (let j = Math.round(i + T * 0.6); j < Math.min(w.length, i + T * 1.4); j++) {
        if (/[,;:\u2014]\s*$/.test(w[j])) {
          if (best < 0 || Math.abs(j - (i + T)) < Math.abs(best - (i + T))) {
            best = j;
          }
        }
      }
      if (best >= 0) k = best + 1;
      r.push(w.slice(i, k).join(''));
      i = k;
    }
    r.push(w.slice(i).join(''));
    return r;
  }

  for (const b of text.split(/\n{2,}/)) {
    if (!b.trim()) continue;
    if (b.startsWith('## ')) {
      flush();
      const h = b.slice(3);
      pend.push(h);
      if (/^(Book the |LITTLE WOMEN PART)/.test(h)) {
        part = h;
        chap = '';
      } else {
        chap = h;
      }
      continue;
    }
    let first = true;
    for (const s of sentences(b)) {
      for (const u of chunks(s)) {
        const n = countWords(u);
        if (!cur) {
          open();
        } else if (cur.words && !pend.length && Math.abs(cur.words + n - T) >= Math.abs(cur.words - T)) {
          flush();
          open();
        }
        if (pend.length) {
          for (const h of pend) (cur as Passage).segs.push(['h', h]);
          pend = [];
        }
        const last = (cur as Passage).segs[(cur as Passage).segs.length - 1];
        if (first || !last || last[0] !== 'p') {
          (cur as Passage).segs.push(['p', u]);
        } else {
          last[1] += u;
        }
        first = false;
        (cur as Passage).words += n;
        word += n;
      }
    }
  }
  flush();

  const L = out[out.length - 1];
  const P = out[out.length - 2];
  if (L && P && L.words < T * opt.minTail && L.segs[0][0] === 'p') {
    for (const s of L.segs) P.segs.push(s);
    P.words += L.words;
    out.pop();
  }
  return out;
}

const num = (v: any, d: number, a: number, b: number) =>
  typeof v === 'number' && isFinite(v) ? Math.min(b, Math.max(a, v)) : d;

function norm(o: any): AppState {
  const r: AppState = {
    sel: IDS.includes(o && o.sel) ? o.sel : IDS[0],
    pos: {},
    marks: {},
    prefs: { target: 60, size: 1.35, anim: true },
  };
  const p = (o && o.prefs) || {};
  IDS.forEach((i) => {
    r.pos[i] = num(o && o.pos && o.pos[i], 0, 0, TOTALS[i]);
    r.marks[i] = ((o && o.marks && o.marks[i]) || [])
      .filter((m: any) => m && typeof m.pos === 'number')
      .map((m: any) => ({ pos: m.pos, x: String(m.x || '').slice(0, 90) }));
  });
  r.prefs = {
    target: num(p.target, 60, 30, 120),
    size: num(p.size, 1.35, 1.1, 1.9),
    anim: p.anim !== false,
  };
  return r;
}

function loadInitialState(): { state: AppState; storageOK: boolean } {
  try {
    const raw = localStorage.getItem(KEY) || localStorage.getItem(OLDKEY);
    return { state: norm(raw ? JSON.parse(raw) : null), storageOK: true };
  } catch {
    return { state: norm(null), storageOK: false };
  }
}

export default function App() {
  const [{ state: initialState, storageOK: initialStorageOK }] = useState(loadInitialState);
  const [S, setS] = useState<AppState>(initialState);
  const [storageOK, setStorageOK] = useState(initialStorageOK);
  const [isSwapping, setIsSwapping] = useState(false);

  // Audio state
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.22);
  const userPausedRef = useRef(false);

  // Dialogs
  const bmDialogRef = useRef<HTMLDialogElement>(null);
  const setDialogRef = useRef<HTMLDialogElement>(null);
  const [statusMsg, setStatusMsg] = useState('');
  const [backupText, setBackupText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Card reference for wheel & touch events
  const cardRef = useRef<HTMLDivElement>(null);

  // Caches for passages split by target word length
  const passageCache = useRef<Record<string, { T: number; ps: Passage[] }>>({});

  const getPassages = useCallback(
    (bookId: string, targetWords: number): Passage[] => {
      const cache = passageCache.current;
      if (!cache[bookId] || cache[bookId].T !== targetWords) {
        cache[bookId] = {
          T: targetWords,
          ps: tetrSplit(BOOKS[bookId].text, { target: targetWords }),
        };
      }
      return cache[bookId].ps;
    },
    []
  );

  const currentPassages = useMemo(() => {
    return getPassages(S.sel, S.prefs.target);
  }, [S.sel, S.prefs.target, getPassages]);

  const findIdx = useCallback(
    (ps: Passage[], pos: number) => {
      let a = 0;
      let b = ps.length - 1;
      while (a < b) {
        const m = (a + b + 1) >> 1;
        ps[m].start <= pos ? (a = m) : (b = m - 1);
      }
      return a;
    },
    []
  );

  const currentBook = BOOKS[S.sel];
  const currentPos = S.pos[S.sel] || 0;
  const currentIdx = findIdx(currentPassages, currentPos);
  const currentPassage = currentPassages[currentIdx] || currentPassages[0];

  // Save state helper
  const saveState = useCallback(
    (next: AppState) => {
      setS(next);
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
        setStorageOK(true);
      } catch {
        setStorageOK(false);
      }
    },
    []
  );

  // Update theme and root variables whenever book or text size changes
  useEffect(() => {
    if (currentBook) {
      document.documentElement.style.setProperty('--a', currentBook.color);
    }
    document.documentElement.style.setProperty('--fs', `${S.prefs.size}rem`);
    document.body.classList.toggle('noanim', !S.prefs.anim);
  }, [currentBook, S.prefs.size, S.prefs.anim]);

  // Audio setup: loop, gentle low volume, try autoplay on load, resume on first tap if blocked
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = volume;
    audio.loop = true;

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          setIsPlaying(true);
        })
        .catch(() => {
          // Autoplay blocked by browser: wait for one user gesture to start
          setIsPlaying(false);
          const handleFirstInteraction = () => {
            if (!userPausedRef.current && audio.paused) {
              audio.play().then(() => setIsPlaying(true)).catch(() => {});
            }
            window.removeEventListener('pointerdown', handleFirstInteraction);
            window.removeEventListener('keydown', handleFirstInteraction);
          };
          window.addEventListener('pointerdown', handleFirstInteraction, { once: true });
          window.addEventListener('keydown', handleFirstInteraction, { once: true });
        });
    }
  }, []);

  const toggleMusic = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (audio.paused) {
      userPausedRef.current = false;
      audio.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      userPausedRef.current = true;
      audio.pause();
      setIsPlaying(false);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (audioRef.current) {
      audioRef.current.volume = newVol;
    }
  };

  // Navigate passage
  const go = useCallback(
    (delta: number) => {
      const ps = currentPassages;
      const curI = findIdx(ps, S.pos[S.sel] || 0);
      const nextI = Math.min(ps.length - 1, Math.max(0, curI + delta));
      if (nextI !== curI) {
        setIsSwapping(true);
        setTimeout(() => setIsSwapping(false), 200);
      }
      const nextPos = ps[nextI].start;
      const nextState: AppState = {
        ...S,
        pos: {
          ...S.pos,
          [S.sel]: nextPos,
        },
      };
      saveState(nextState);
      window.scrollTo({ top: 0, behavior: 'instant' });
    },
    [currentPassages, findIdx, S, saveState]
  );

  // Switch book
  const pick = useCallback(
    (bookId: string) => {
      setIsSwapping(true);
      setTimeout(() => setIsSwapping(false), 200);
      const ps = getPassages(bookId, S.prefs.target);
      const pos = S.pos[bookId] || 0;
      const idx = findIdx(ps, pos);
      const actualPos = ps[idx].start;

      const nextState: AppState = {
        ...S,
        sel: bookId,
        pos: {
          ...S.pos,
          [bookId]: actualPos,
        },
      };
      saveState(nextState);
      window.scrollTo({ top: 0, behavior: 'instant' });
    },
    [getPassages, S, findIdx, saveState]
  );

  // Bookmarking
  const isPassageMarked = useCallback(
    (p: Passage) => {
      const marks = S.marks[S.sel] || [];
      return marks.some((m) => m.pos >= p.start && m.pos < p.start + p.words);
    },
    [S.marks, S.sel]
  );

  const toggleMark = useCallback(() => {
    const ps = currentPassages;
    const p = ps[findIdx(ps, S.pos[S.sel] || 0)];
    const marks = [...(S.marks[S.sel] || [])];
    const currentlyMarked = isPassageMarked(p);

    let nextMarks: Bookmark[];
    if (currentlyMarked) {
      nextMarks = marks.filter((m) => !(m.pos >= p.start && m.pos < p.start + p.words));
    } else {
      const textPiece = p.segs
        .filter((s) => s[0] === 'p')
        .map((s) => s[1])
        .join(' ')
        .trim();
      nextMarks = [...marks, { pos: p.start, x: textPiece.slice(0, 80) }];
      nextMarks.sort((a, b) => a.pos - b.pos);
    }

    const nextState: AppState = {
      ...S,
      marks: {
        ...S.marks,
        [S.sel]: nextMarks,
      },
    };
    saveState(nextState);
  }, [currentPassages, findIdx, isPassageMarked, S, saveState]);

  // Keyboard navigation
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.metaKey ||
        e.ctrlKey ||
        e.altKey ||
        document.querySelector('dialog[open]') ||
        /INPUT|TEXTAREA/.test((e.target as HTMLElement)?.tagName)
      ) {
        return;
      }
      if (e.key === 'ArrowRight') go(1);
      else if (e.key === 'ArrowLeft') go(-1);
      else if (/^[1-5]$/.test(e.key)) {
        const idx = parseInt(e.key, 10) - 1;
        if (IDS[idx]) pick(IDS[idx]);
      } else if (e.key === 'b' || e.key === 'B') toggleMark();
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [go, pick, toggleMark]);

  // Wheel and Touch navigation on the card
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const edge = (d: number) => {
      const e = document.documentElement;
      return d > 0 ? window.innerHeight + window.scrollY >= e.scrollHeight - 4 : window.scrollY <= 4;
    };

    let lastW = 0;
    let okW = false;
    let lockW = false;
    let acc = 0;

    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
      const t = performance.now();
      if (t - lastW > 180) {
        okW = edge(Math.sign(e.deltaY));
        lockW = false;
        acc = 0;
      }
      lastW = t;
      if (!okW || lockW) return;
      acc += e.deltaY;
      if (Math.abs(acc) >= 40) {
        e.preventDefault();
        lockW = true;
        go(acc > 0 ? 1 : -1);
      }
    };

    let tx = 0;
    let ty = 0;
    let bot = false;
    let top = false;

    const onTouchStart = (e: TouchEvent) => {
      tx = e.touches[0].clientX;
      ty = e.touches[0].clientY;
      bot = edge(1);
      top = edge(-1);
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (String(window.getSelection())) return;
      const dx = e.changedTouches[0].clientX - tx;
      const dy = e.changedTouches[0].clientY - ty;
      if (Math.abs(dy) > 70 && Math.abs(dx) < 50) {
        if (dy < 0 && bot) go(1);
        else if (dy > 0 && top) go(-1);
      } else if (Math.abs(dx) > 80 && Math.abs(dy) < 40) {
        go(dx < 0 ? 1 : -1);
      }
    };

    card.addEventListener('wheel', onWheel, { passive: false });
    card.addEventListener('touchstart', onTouchStart, { passive: true });
    card.addEventListener('touchend', onTouchEnd, { passive: true });

    return () => {
      card.removeEventListener('wheel', onWheel);
      card.removeEventListener('touchstart', onTouchStart);
      card.removeEventListener('touchend', onTouchEnd);
    };
  }, [go]);

  // Scrub slider change
  const handleScrubChange = (val: number) => {
    const ps = currentPassages;
    const targetIdx = val - 1;
    if (ps[targetIdx]) {
      const nextPos = ps[targetIdx].start;
      const nextState: AppState = {
        ...S,
        pos: {
          ...S.pos,
          [S.sel]: nextPos,
        },
      };
      saveState(nextState);
    }
  };

  // Surprise me
  const handleSurprise = () => {
    const others = IDS.filter((i) => i !== S.sel);
    const chosen = others[Math.floor(Math.random() * others.length)];
    pick(chosen);
  };

  // Export / Copy / Import
  const dumpState = () =>
    JSON.stringify({ app: 'readr', v: 1, saved: new Date().toISOString(), ...S }, null, 1);

  const handleExport = () => {
    const j = dumpState();
    setBackupText(j);
    try {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([j], { type: 'application/json' }));
      a.download = 'readr-backup.json';
      a.click();
      setStatusMsg('Backup created. If no file downloaded, use Copy.');
    } catch {
      setStatusMsg('Backup is in the box. Use Copy.');
    }
  };

  const handleCopy = async () => {
    const j = backupText || dumpState();
    setBackupText(j);
    try {
      await navigator.clipboard.writeText(j);
      setStatusMsg('Copied.');
    } catch {
      setStatusMsg('Press Ctrl/Cmd+C to copy.');
    }
  };

  const handleImportText = (t: string) => {
    try {
      const o = JSON.parse(t);
      if (!o || (o.app !== 'readr' && o.app !== 'tetr')) throw new Error();
      const next = norm(o);
      passageCache.current = {};
      saveState(next);
      setStatusMsg('Restored.');
    } catch {
      setStatusMsg("That doesn’t look like a Readr backup.");
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      f.text().then((t) => {
        setBackupText(t);
        handleImportText(t);
      });
    }
  };

  // Percentage calculations
  const totalWords = TOTALS[S.sel] || 1;
  const passageStart = currentPassage.start;
  const passageWords = currentPassage.words;
  const pct = Math.round((1000 * (passageStart + passageWords)) / totalWords) / 10;
  const isMarked = isPassageMarked(currentPassage);

  // Render passage text with formatting
  const renderFormattedText = (text: string) => {
    // replace _italic_ with <em>
    const parts = text.split(/_([^_\n]+)_/g);
    return parts.map((part, i) => (i % 2 === 1 ? <em key={i}>{part}</em> : part));
  };

  return (
    <>
      {/* Background soft jazz audio element */}
      <audio
        ref={audioRef}
        src="/audio/soft-jazz.mp3"
        preload="auto"
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
      />

      <header>
        <div className="stripe" aria-hidden="true" />
        <div className="bar">
          <div className="wm" aria-label="Readr">
            Readr
            <i className="plaid" style={{ '--a': 'var(--lv)' } as React.CSSProperties} />
          </div>

          {/* Simple, gentle Play/Pause button for soft background jazz */}
          <button
            className="pill"
            id="musicBtn"
            onClick={toggleMusic}
            aria-pressed={isPlaying}
            title={isPlaying ? 'Pause background jazz' : 'Play soft background jazz'}
            aria-label={isPlaying ? 'Pause background jazz' : 'Play soft background jazz'}
          >
            {isPlaying ? (
              <>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <rect x="6" y="4" width="4" height="16" rx="1" />
                  <rect x="14" y="4" width="4" height="16" rx="1" />
                </svg>
                <span>Jazz ⏸</span>
              </>
            ) : (
              <>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
                <span>Jazz ▶</span>
              </>
            )}
          </button>

          <button
            className="pill"
            id="surprise"
            onClick={handleSurprise}
            title="Switch to a different book"
          >
            Surprise me
          </button>
          <button
            className="pill"
            id="bmBtn"
            onClick={() => bmDialogRef.current?.showModal()}
          >
            Bookmarks
          </button>
          <button
            className="pill"
            id="setBtn"
            onClick={() => {
              setBackupText('');
              setStatusMsg('');
              setDialogRef.current?.showModal();
            }}
          >
            Settings
          </button>
        </div>

        {/* Five Books Navigation Tabs */}
        <nav id="books" aria-label="Your five books">
          {IDS.map((id, k) => {
            const b = BOOKS[id];
            const p = Math.round((100 * (S.pos[id] || 0)) / TOTALS[id]);
            const isCurrent = id === S.sel;
            return (
              <button
                key={id}
                className="tab"
                data-id={id}
                style={{ '--a': b.color } as React.CSSProperties}
                aria-current={isCurrent}
                aria-keyshortcuts={String(k + 1)}
                aria-label={`${b.title} by ${b.author}, ${p}% read`}
                onClick={() => pick(id)}
              >
                <b>{b.short}</b>
                <small>
                  {b.author} · {p}%
                </small>
                <div className="pr">
                  <i style={{ width: `${p}%` }} />
                </div>
              </button>
            );
          })}
        </nav>
      </header>

      {/* Warning banner if storage is unavailable */}
      {!storageOK && (
        <div id="warn" className="warn">
          Your browser is blocking local storage, so progress will be lost when this page closes. You
          can still use Settings → Export to keep a backup.
        </div>
      )}

      {/* Main Reading Card */}
      <main>
        <section className="card" id="card" ref={cardRef} aria-label="Reading">
          <div className="plaid" aria-hidden="true" />
          <div className="in">
            <div className="meta">
              <span>
                <strong id="bt">{currentBook.title}</strong> ·{' '}
                <span id="ba">{currentBook.author}</span>
              </span>
              <span id="pc" aria-live="polite">
                Passage {(currentIdx + 1).toLocaleString()} of{' '}
                {currentPassages.length.toLocaleString()} · {currentPassage.words} words
              </span>
            </div>

            <p className="ch" id="chap">
              {currentPassage.ch || '\u00a0'}
            </p>

            <article
              id="txt"
              className={isSwapping ? 'swap' : ''}
              aria-live="polite"
            >
              {currentPassage.segs.map(([kind, text], idx) => {
                if (kind === 'h') {
                  return <h2 key={idx}>{text}</h2>;
                }
                return <p key={idx}>{renderFormattedText(text.trim())}</p>;
              })}
            </article>

            <div className="ctl">
              <button
                className="btn"
                id="mark"
                aria-pressed={isMarked}
                onClick={toggleMark}
              >
                {isMarked ? 'Bookmarked' : 'Bookmark'}
              </button>
              <span className="hint" id="hint" aria-hidden="true">
                {currentIdx === currentPassages.length - 1
                  ? 'The end — thank you for reading'
                  : currentIdx === 0
                  ? 'Scroll or swipe up for the next passage'
                  : '↑ scroll back · scroll on ↓'}
              </span>
            </div>

            <div className="sl">
              <label htmlFor="scrub" className="note">
                Passage
              </label>
              <input
                type="range"
                id="scrub"
                min="1"
                max={currentPassages.length}
                value={currentIdx + 1}
                aria-valuetext={`Passage ${currentIdx + 1} of ${currentPassages.length}`}
                onChange={(e) => handleScrubChange(Number(e.target.value))}
              />
              <span id="pct">{pct}%</span>
            </div>

            <div className="ptrack" aria-hidden="true">
              <i id="pbar" style={{ width: `${pct}%` }} />
            </div>
          </div>
        </section>
      </main>

      {/* Bookmarks Modal Dialog */}
      <dialog id="dBm" ref={bmDialogRef}>
        <div className="dg">
          <h3>Bookmarks</h3>
          <div id="bmList">
            {IDS.some((id) => (S.marks[id] || []).length > 0) ? (
              IDS.map((id) => {
                const marks = S.marks[id] || [];
                if (!marks.length) return null;
                return (
                  <div key={id}>
                    <p className="note" style={{ margin: '1rem 0 0' }}>
                      <b>{BOOKS[id].title}</b>
                    </p>
                    {marks.map((m) => {
                      const bookPct = Math.round((100 * m.pos) / TOTALS[id]);
                      return (
                        <div className="bm" key={m.pos}>
                          <button
                            className="btn"
                            onClick={() => {
                              const nextState: AppState = {
                                ...S,
                                sel: id,
                                pos: { ...S.pos, [id]: m.pos },
                              };
                              saveState(nextState);
                              bmDialogRef.current?.close();
                            }}
                          >
                            {bookPct}% · {m.x}…
                          </button>
                          <button
                            className="btn x"
                            aria-label="Remove bookmark"
                            onClick={() => {
                              const nextMarks = marks.filter((item) => item.pos !== m.pos);
                              const nextState: AppState = {
                                ...S,
                                marks: { ...S.marks, [id]: nextMarks },
                              };
                              saveState(nextState);
                            }}
                          >
                            ×
                          </button>
                        </div>
                      );
                    })}
                  </div>
                );
              })
            ) : (
              <p className="note">No bookmarks yet. Use the Bookmark button under any passage.</p>
            )}
          </div>
          <div className="row">
            <button className="btn" onClick={() => bmDialogRef.current?.close()}>
              Close
            </button>
          </div>
        </div>
      </dialog>

      {/* Settings Modal Dialog */}
      <dialog id="dSet" ref={setDialogRef}>
        <div className="dg">
          <h3>Settings</h3>

          <label htmlFor="sT">
            Passage length: <span id="vT">{S.prefs.target}</span> words
          </label>
          <input
            type="range"
            id="sT"
            min="30"
            max="120"
            step="5"
            style={{ width: '100%' }}
            value={S.prefs.target}
            onChange={(e) => {
              const val = Number(e.target.value);
              const nextState: AppState = {
                ...S,
                prefs: { ...S.prefs, target: val },
              };
              saveState(nextState);
            }}
          />
          <p className="note">
            Aims for this many words, ending on a sentence where it can. Your place is kept when you
            change it.
          </p>

          <label htmlFor="sF">Text size</label>
          <input
            type="range"
            id="sF"
            min="1.1"
            max="1.9"
            step="0.05"
            style={{ width: '100%' }}
            value={S.prefs.size}
            onChange={(e) => {
              const val = Number(e.target.value);
              const nextState: AppState = {
                ...S,
                prefs: { ...S.prefs, size: val },
              };
              saveState(nextState);
            }}
          />

          <label>
            <input
              type="checkbox"
              id="sA"
              checked={S.prefs.anim}
              onChange={(e) => {
                const checked = e.target.checked;
                const nextState: AppState = {
                  ...S,
                  prefs: { ...S.prefs, anim: checked },
                };
                saveState(nextState);
              }}
            />{' '}
            Soft fade between passages
          </label>

          <label htmlFor="sVol">
            Background jazz volume: <span>{Math.round(volume * 100)}%</span>
          </label>
          <input
            type="range"
            id="sVol"
            min="0"
            max="1"
            step="0.02"
            style={{ width: '100%' }}
            value={volume}
            onChange={(e) => handleVolumeChange(Number(e.target.value))}
          />

          <label htmlFor="bk">Backup &amp; restore (progress, bookmarks, preferences)</label>
          <textarea
            id="bk"
            spellCheck="false"
            placeholder="Export fills this box. To restore, paste a backup here or choose a file, then press Import."
            value={backupText}
            onChange={(e) => setBackupText(e.target.value)}
          />

          <div className="row">
            <button className="btn" id="ex" onClick={handleExport}>
              Export
            </button>
            <button className="btn" id="cp" onClick={handleCopy}>
              Copy
            </button>
            <button className="btn" id="im" onClick={() => handleImportText(backupText)}>
              Import
            </button>
            <label className="btn" style={{ margin: 0, fontWeight: 400 }}>
              Choose file
              <input
                type="file"
                id="fl"
                ref={fileInputRef}
                accept=".json,application/json"
                hidden
                onChange={handleFileUpload}
              />
            </label>
          </div>

          {statusMsg && (
            <p className="note" id="msg" role="status">
              {statusMsg}
            </p>
          )}

          <p className="note">
            Everything stays in this browser. No accounts, analytics or tracking. Texts: Project
            Gutenberg, public domain.
          </p>
          <p className="note" style={{ marginTop: '0.4rem', fontSize: '0.78rem' }}>
            Music: "Backed Vibes Clean" by Kevin MacLeod (incompetech.com), Licensed under Creative Commons: By Attribution 3.0.
          </p>

          <div className="row">
            <button className="btn" onClick={() => setDialogRef.current?.close()}>
              Done
            </button>
          </div>
        </div>
      </dialog>
    </>
  );
}
